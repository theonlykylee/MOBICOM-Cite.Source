/** Automatically generated file. DO NOT MODIFY */
package com.gsm.cite.source;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}